'use strict';

var $ = window.jQuery = window.$ = module.exports = require('node_modules/jquery/dist/jquery');
require('ui/jquery/findTestSubject')($);
